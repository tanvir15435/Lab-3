import autograder
import gridworld
import pacman

autograder.main('python3 -q q1')
#autograder.main('python3 -q q2')
#autograder.main('python3 -t test_cases/q1/1-tinygrid')

#gridworld.main('python3 gridworld.py -a q -k 100 -n 0 -m  -l 0.1 -d 0.85 -g VerticalBridgeGrid')

#pacman.main('pacman.py -p PacmanQAgent -x 2000 -n 2010 -l smallGrid')

